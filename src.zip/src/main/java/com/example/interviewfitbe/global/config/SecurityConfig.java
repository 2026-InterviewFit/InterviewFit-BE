package com.example.interviewfitbe.global.config;

import com.example.interviewfitbe.global.jwt.JwtAuthenticationFilter;
import com.example.interviewfitbe.global.jwt.JwtTokenProvider;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.nio.charset.StandardCharsets;
import java.util.List;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtTokenProvider jwtTokenProvider;


    @Bean
    public SecurityFilterChain filterChain(
            HttpSecurity http
    ) throws Exception {

        http

                /*
                 * =========================================
                 * CORS
                 * =========================================
                 */
                .cors(cors ->
                        cors.configurationSource(
                                corsConfigurationSource()
                        )
                )


                /*
                 * =========================================
                 * CSRF
                 * =========================================
                 *
                 * 현재 로컬 개발 단계에서는 비활성화.
                 *
                 * HttpOnly Cookie 인증 전환 완료 후
                 * 실제 배포 전에는 CSRF 전략을
                 * 별도로 적용하는 것이 좋다.
                 */
                .csrf(csrf ->
                        csrf.disable()
                )


                /*
                 * =========================================
                 * Spring Session 사용 안 함
                 * =========================================
                 *
                 * JWT 기반 Stateless 인증
                 */
                .sessionManagement(session ->
                        session.sessionCreationPolicy(
                                SessionCreationPolicy.STATELESS
                        )
                )


                .httpBasic(httpBasic ->
                        httpBasic.disable()
                )


                .formLogin(formLogin ->
                        formLogin.disable()
                )


                /*
                 * =========================================
                 * 401 / 403 응답
                 * =========================================
                 */
                .exceptionHandling(exception ->
                        exception

                                /*
                                 * 로그인 안 됨
                                 * 또는 유효한 인증정보 없음
                                 */
                                .authenticationEntryPoint(
                                        (
                                                request,
                                                response,
                                                authException
                                        ) -> {

                                            response.setStatus(
                                                    401
                                            );

                                            response.setCharacterEncoding(
                                                    StandardCharsets.UTF_8.name()
                                            );

                                            response.setContentType(
                                                    MediaType.APPLICATION_JSON_VALUE
                                            );

                                            response
                                                    .getWriter()
                                                    .write(
                                                            """
                                                            {
                                                              "status": 401,
                                                              "code": "UNAUTHORIZED",
                                                              "message": "로그인이 필요합니다."
                                                            }
                                                            """
                                                    );
                                        }
                                )


                                /*
                                 * 로그인은 됐지만
                                 * 권한이 없는 경우
                                 */
                                .accessDeniedHandler(
                                        (
                                                request,
                                                response,
                                                accessDeniedException
                                        ) -> {

                                            response.setStatus(
                                                    403
                                            );

                                            response.setCharacterEncoding(
                                                    StandardCharsets.UTF_8.name()
                                            );

                                            response.setContentType(
                                                    MediaType.APPLICATION_JSON_VALUE
                                            );

                                            response
                                                    .getWriter()
                                                    .write(
                                                            """
                                                            {
                                                              "status": 403,
                                                              "code": "FORBIDDEN",
                                                              "message": "해당 요청에 접근할 권한이 없습니다."
                                                            }
                                                            """
                                                    );
                                        }
                                )
                )


                /*
                 * =========================================
                 * API 접근 권한
                 * =========================================
                 */
                .authorizeHttpRequests(auth ->
                        auth

                                /*
                                 * 브라우저 CORS Preflight
                                 */
                                .requestMatchers(
                                        HttpMethod.OPTIONS,
                                        "/**"
                                )
                                .permitAll()


                                /*
                                 * =================================
                                 * 인증 없이 접근 가능
                                 * =================================
                                 */
                                .requestMatchers(

                                        "/error",

                                        /*
                                         * 카카오 로그인
                                         */
                                        "/api/users/kakao-login",

                                        /*
                                         * Access Token 재발급.
                                         *
                                         * Refresh Cookie 자체를
                                         * Controller에서 검증한다.
                                         */
                                        "/api/users/refresh",

                                        /*
                                         * Access Token이 만료된 상태에서도
                                         * Cookie를 삭제할 수 있어야 한다.
                                         */
                                        "/api/users/logout",

                                        /*
                                         * 공개 직무 목록
                                         */
                                        "/api/job-role/**",

                                        "/webhook/**",

                                        "/api/group/**",

                                        "/api/group-interviews/**",

                                        "/ws-interview/**"
                                )
                                .permitAll()


                                /*
                                 * =================================
                                 * 나머지 API
                                 *
                                 * /api/users/me 포함.
                                 * =================================
                                 */
                                .anyRequest()
                                .authenticated()
                )


                /*
                 * =========================================
                 * JWT Filter
                 * =========================================
                 *
                 * 아직 이 단계에서는
                 * Authorization Bearer Token 방식.
                 *
                 * 다음 단계에서 Cookie의
                 * interviewfit_access_token도
                 * 읽도록 변경한다.
                 */
                .addFilterBefore(
                        new JwtAuthenticationFilter(
                                jwtTokenProvider
                        ),
                        UsernamePasswordAuthenticationFilter.class
                );


        return http.build();
    }


    /**
     * =====================================================
     * CORS
     * =====================================================
     */
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {

        CorsConfiguration configuration =
                new CorsConfiguration();


        /*
         * allowCredentials(true)를 사용하므로
         * allowedOrigins에 "*"를 사용할 수 없다.
         *
         * 실제 FE 주소를 명시한다.
         */
        configuration.setAllowedOrigins(
                List.of(
                        "http://localhost:3000",
                        "http://127.0.0.1:3000",

                        /*
                         * 현재 개발 Network 주소
                         */
                        "http://172.20.2.15:3000",

                        /*
                         * 기존 개발 주소
                         */
                        "http://172.20.14.83:3000"
                )
        );


        configuration.setAllowedMethods(
                List.of(
                        "GET",
                        "POST",
                        "PUT",
                        "PATCH",
                        "DELETE",
                        "OPTIONS"
                )
        );


        configuration.setAllowedHeaders(
                List.of(
                        "*"
                )
        );


        configuration.setExposedHeaders(
                List.of(
                        "Authorization"
                )
        );


        /*
         * ★ 매우 중요
         *
         * 브라우저가 쿠키를 포함한 요청을
         * Spring으로 보낼 수 있게 한다.
         */
        configuration.setAllowCredentials(
                true
        );


        UrlBasedCorsConfigurationSource source =
                new UrlBasedCorsConfigurationSource();


        source.registerCorsConfiguration(
                "/**",
                configuration
        );


        return source;
    }
}